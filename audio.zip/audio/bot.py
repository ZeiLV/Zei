import os
import asyncio
from aiogram import Bot, Dispatcher, F
from aiogram.types import Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton, FSInputFile
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.fsm.storage.memory import MemoryStorage
from mutagen.mp3 import MP3
from mutagen.id3 import ID3, TIT2, TPE1, APIC, ID3NoHeaderError

TOKEN = '8833196998:AAHtCvk_KrjKwaFJo4DdToIUb90GfyOfFF8'

bot = Bot(token=TOKEN)
dp = Dispatcher(storage=MemoryStorage())


class AudioEdit(StatesGroup):
    waiting_for_audio = State()
    waiting_for_title = State()
    waiting_for_artist = State()
    waiting_for_cover = State()


user_data_store: dict[int, dict] = {}


def get_menu_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🎵 Nomini o'zgartirish", callback_data="edit_title")],
        [InlineKeyboardButton(text="👤 Ijrochini o'zgartirish", callback_data="edit_artist")],
        [InlineKeyboardButton(text="🖼 Muqova (rasm) qo'shish", callback_data="edit_cover")],
        [InlineKeyboardButton(text="✅ Saqlash va yuborish", callback_data="save_audio")],
    ])


# /start
@dp.message(F.text == "/start")
async def start_cmd(message: Message, state: FSMContext):
    await state.clear()
    await message.answer("Salom! Tahrirlamoqchi bo'lgan MP3 qo'shig'ingizni yuboring.")
    await state.set_state(AudioEdit.waiting_for_audio)


# Audio qabul qilish
@dp.message(AudioEdit.waiting_for_audio, F.audio)
async def handle_audio(message: Message, state: FSMContext):
    audio = message.audio
    file_name = audio.file_name or "music.mp3"
    if not file_name.lower().endswith(".mp3"):
        await message.answer("❌ Faqat MP3 formatidagi fayllar qabul qilinadi.")
        return

    os.makedirs("downloads", exist_ok=True)
    local_path = f"downloads/{message.from_user.id}_{file_name}"

    file = await bot.get_file(audio.file_id)
    await bot.download_file(file.file_path, local_path)

    user_data_store[message.from_user.id] = {
        "file_path": local_path,
        "title": audio.title or "Noma'lum",
        "artist": audio.performer or "Noma'lum",
        "cover": None,
    }

    title = audio.title or "Noma'lum"
    artist = audio.performer or "Noma'lum"

    await message.answer(
        f"✅ Qo'shiq yuklandi!\n\n"
        f"🎵 *Nomi:* {title}\n"
        f"👤 *Ijrochi:* {artist}\n\n"
        f"Nimani o'zgartirmoqchisiz?",
        reply_markup=get_menu_keyboard(),
        parse_mode="Markdown",
    )
    # Menyu ko'rsatilgach holatni tozalaymiz — foydalanuvchi faqat
    # callback tugmalar orqali keyingi holatlarga o'tadi.
    await state.set_state(AudioEdit.waiting_for_audio)


# Nom o'zgartirish
@dp.callback_query(F.data == "edit_title")
async def cb_edit_title(callback: CallbackQuery, state: FSMContext):
    await callback.answer()
    await callback.message.answer("Qo'shiq uchun yangi nom yozing:")
    await state.set_state(AudioEdit.waiting_for_title)


@dp.message(AudioEdit.waiting_for_title, F.text)
async def set_title(message: Message, state: FSMContext):
    uid = message.from_user.id
    if uid not in user_data_store:
        await message.answer("❌ Avval MP3 fayl yuboring.")
        await state.set_state(AudioEdit.waiting_for_audio)
        return

    user_data_store[uid]["title"] = message.text.strip()
    await message.answer(
        f"✅ Nom saqlandi: *{message.text.strip()}*\n\nDavom etish uchun:",
        reply_markup=get_menu_keyboard(),
        parse_mode="Markdown",
    )
    await state.set_state(AudioEdit.waiting_for_audio)


# Ijrochi o'zgartirish
@dp.callback_query(F.data == "edit_artist")
async def cb_edit_artist(callback: CallbackQuery, state: FSMContext):
    await callback.answer()
    await callback.message.answer("Yangi ijrochi yoki kanal nomini yozing:")
    await state.set_state(AudioEdit.waiting_for_artist)


@dp.message(AudioEdit.waiting_for_artist, F.text)
async def set_artist(message: Message, state: FSMContext):
    uid = message.from_user.id
    if uid not in user_data_store:
        await message.answer("❌ Avval MP3 fayl yuboring.")
        await state.set_state(AudioEdit.waiting_for_audio)
        return

    user_data_store[uid]["artist"] = message.text.strip()
    await message.answer(
        f"✅ Ijrochi saqlandi: *{message.text.strip()}*\n\nDavom etish uchun:",
        reply_markup=get_menu_keyboard(),
        parse_mode="Markdown",
    )
    await state.set_state(AudioEdit.waiting_for_audio)


# Muqova qo'shish
@dp.callback_query(F.data == "edit_cover")
async def cb_edit_cover(callback: CallbackQuery, state: FSMContext):
    await callback.answer()
    await callback.message.answer("Muqova sifatida ishlatmoqchi bo'lgan rasmni yuboring:")
    await state.set_state(AudioEdit.waiting_for_cover)


@dp.message(AudioEdit.waiting_for_cover, F.photo)
async def set_cover(message: Message, state: FSMContext):
    uid = message.from_user.id
    if uid not in user_data_store:
        await message.answer("❌ Avval MP3 fayl yuboring.")
        await state.set_state(AudioEdit.waiting_for_audio)
        return

    os.makedirs("downloads", exist_ok=True)
    cover_path = f"downloads/cover_{uid}.jpg"
    photo = message.photo[-1]          # eng yuqori sifatli rasm
    file = await bot.get_file(photo.file_id)
    await bot.download_file(file.file_path, cover_path)

    user_data_store[uid]["cover"] = cover_path
    await message.answer(
        "✅ Muqova saqlandi!\n\nDavom etish uchun:",
        reply_markup=get_menu_keyboard(),
    )
    await state.set_state(AudioEdit.waiting_for_audio)


# Saqlash va yuborish
@dp.callback_query(F.data == "save_audio")
async def save_and_send(callback: CallbackQuery, state: FSMContext):
    await callback.answer()
    uid = callback.from_user.id
    data = user_data_store.get(uid)

    if not data or not os.path.exists(data["file_path"]):
        await callback.message.answer("❌ Fayl topilmadi. Iltimos, qo'shiqni qaytadan yuboring.")
        await state.set_state(AudioEdit.waiting_for_audio)
        return

    await callback.message.answer("⏳ Fayl tayyorlanmoqda, biroz kuting...")

    audio_path = data["file_path"]
    try:
        audio = MP3(audio_path, ID3=ID3)
        if audio.tags is None:
            audio.add_tags()
    except ID3NoHeaderError:
        audio = MP3(audio_path)
        audio.add_tags()
    except Exception as e:
        await callback.message.answer(f"❌ Faylni o'qishda xato: {e}")
        return

    audio.tags.add(TIT2(encoding=3, text=data["title"]))
    audio.tags.add(TPE1(encoding=3, text=data["artist"]))

    cover_path = data.get("cover")
    if cover_path and os.path.exists(cover_path):
        with open(cover_path, "rb") as img:
            audio.tags.add(APIC(
                encoding=3,
                mime="image/jpeg",
                type=3,
                desc="Cover",
                data=img.read(),
            ))

    audio.save()

    safe_name = f"{data['artist']} - {data['title']}.mp3".replace("/", "_")
    ready_file = FSInputFile(audio_path, filename=safe_name)

    await bot.send_audio(
        chat_id=callback.message.chat.id,
        audio=ready_file,
        title=data["title"],
        performer=data["artist"],
    )

    # Fayllarni tozalash
    for path in [audio_path, cover_path]:
        if path and os.path.exists(path):
            os.remove(path)
    user_data_store.pop(uid, None)
    await state.clear()

    await callback.message.answer(
        "🎉 Tayyor! Yangi qo'shiq yuborildi.\n\nYangi qo'shiq tahrirlash uchun /start ni bosing."
    )


# Noto'g'ri holatlarda kelgan xabarlarni tutib olish
@dp.message(AudioEdit.waiting_for_audio)
async def wrong_input_audio(message: Message):
    await message.answer("Iltimos, MP3 fayl yuboring.")


@dp.message(AudioEdit.waiting_for_title)
async def wrong_input_title(message: Message):
    await message.answer("Iltimos, nom uchun matn yozing.")


@dp.message(AudioEdit.waiting_for_artist)
async def wrong_input_artist(message: Message):
    await message.answer("Iltimos, ijrochi nomi uchun matn yozing.")


@dp.message(AudioEdit.waiting_for_cover)
async def wrong_input_cover(message: Message):
    await message.answer("Iltimos, rasm (foto) yuboring.")


if __name__ == "__main__":
    asyncio.run(dp.start_polling(bot))
